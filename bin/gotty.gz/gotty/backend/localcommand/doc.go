// Package localcommand provides an implementation of webtty.Slave
// that launches a local command with a PTY.
package localcommand
