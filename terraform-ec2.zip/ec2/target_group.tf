resource "aws_lb_target_group" "controlplane" {
  name             = join("-", [var.prefix, "tg"])
  target_type      = "instance"
  port             = 443
  protocol         = "HTTPS"
  protocol_version = "HTTP1"
  vpc_id           = aws_vpc.vpc.id
  health_check {
    port              = 443
    path              = "/api"
    protocol          = "HTTPS"
    healthy_threshold = 2
  }
  tags = {
    Project = local.prefix
    Name    = join("-", [var.prefix, "target-group"])
  }
}
resource "aws_lb_target_group_attachment" "controlplane_attachment" {
  target_group_arn = aws_lb_target_group.controlplane.arn
  target_id        = aws_instance.roost_controlplane.id
  port             = 443
}
