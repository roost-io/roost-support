resource "aws_eip" "roostgpt_eip1" {
  vpc = true
  tags = {
    Project = local.prefix
    Name    = join("-", [var.prefix, "eip-1"])
  }
}
resource "aws_eip" "roostgpt_eip2" {
  vpc = true
  tags = {
    Project = local.prefix
    Name    = join("-", [var.prefix, "eip-2"])
  }
}
resource "aws_nat_gateway" "roostgpt_nat_gateway1" {
  allocation_id = aws_eip.roostgpt_eip1.id
  subnet_id     = aws_subnet.roostgpt_public_subnet1.id
  tags = {
    Project = local.prefix
    Name    = join("-", [var.prefix, "nat-gateway-1"])
  }
}
resource "aws_nat_gateway" "roostgpt_nat_gateway2" {
  allocation_id = aws_eip.roostgpt_eip2.id
  subnet_id     = aws_subnet.roostgpt_public_subnet2.id
  tags = {
    Project = local.prefix
    Name    = join("-", [var.prefix, "nat-gateway-2"])
  }
}
