resource "aws_vpc" "vpc" {
  cidr_block = join("/", [var.ip_block_vpc, "26"])
  tags = {
    Project = local.prefix
    Name    = join("-", [var.prefix, "vpc"])
  }
}
resource "aws_internet_gateway" "roostgpt_internet_gateway" {
  vpc_id = aws_vpc.vpc.id
  tags = {
    Project = local.prefix
    Name    = join("-", [var.prefix, "igw"])
  }
}
