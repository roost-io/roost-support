enterprise_dns = "roost.aquera.com"
admin_email = "roopa.balappa@aquera.com,ashok.sonnad@aquera.com"
enterprise_email_domain = "aquera.com"
company = "Aquera"
license_key = "8fe3048e-dfda-415b-bded-98c068b8357d"
roost_jwt_token = "32-character-secure-long-secret"
roost_version = "v1.1.14"

az1_suffix = "b"
az2_suffix = "c"
certificate_arn = "arn:aws:acm:ap-south-1:872232775305:certificate/cd0ae057-8248-4373-8309-7db222b1a909"
ec2_ami = "ami-023a307f3d27ea427"
region = "ap-south-1"
ip_block_vpc="172.32.255.192"
route53_hosted_zone_id = ""
key_pair = "roost-ssh"

azure_tenant_id = ""
azure_client_id = ""
azure_client_secret = ""
okta_client_id = "0oa3x8katznHWlHeD5d7"
okta_client_secret = "7WtBP5NPtqx_VQlEFQms6Gf2cRS-n58pIJ-nifvc"
okta_issuer = "https://dev-53854943.okta.com/oauth2/default"


is_own_mysql = false
mysql_db_name = "roostio"
mysql_host = "mysqldb_host_url"
mysql_password = "Roost#123"
mysql_port = 3306
mysql_root_password = "Admin#123"
mysql_username = "Roost"
