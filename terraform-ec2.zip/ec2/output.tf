output "controlplane_id" {
  value = aws_instance.roost_controlplane.id
}
output "server_id" {
  value = length(aws_instance.roostgpt_server) > 0 ? "${aws_instance.roostgpt_server[0].id}" : null
}
output "jumphost_id" {
  value = length(aws_instance.roost_bastion) > 0 ? "${aws_instance.roost_bastion.id}" : null
}
output "jumphost_public_ip" {
  value = length(aws_instance.roost_bastion) > 0 ? "${aws_instance.roost_bastion.public_ip}" : null
}
output "jumphost_public_dns" {
  value = length(aws_instance.roost_bastion) > 0 ? "${aws_instance.roost_bastion.public_dns}" : null
}
output "jumphost_private_dns" {
  value = length(aws_instance.roost_bastion) > 0 ? "${aws_instance.roost_bastion.private_dns}" : null
}
output "ssh_id" {
  value = aws_instance.roost_bastion.id
}
output "ssh_public_ip" {
  value = aws_instance.roost_bastion.public_ip
}
output "roostgpt_endpoint" {
  value = var.enterprise_dns
}
output "hostedzone_id" {
  value = length(data.aws_route53_zone.roostgpt) > 0 ? data.aws_route53_zone.roostgpt[0].zone_id : null
}
output "loadbalancer_url" {
  value = aws_lb.roostgpt_load_balancer.dns_name
}
