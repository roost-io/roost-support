# Roost Setup from Terraform

This terraform script allows to setup Roost for enterprise customers. User has to provide valid Route 53 hosted zone where provided subdomain would be configured to access Roost.

Okta, Google, Github, Linked and Azure can be configured as Third-party auth provider to login into Roost.

By default, mysql container would be launched in controlplane instance to store Roost data. 
It is recommended to use RDS or other mysql/postgres database; set var.is_own_mysql = true and update all `var.mysql_` with necessary details.

## Prerequisites

- Copy [terraform.tfvars.original](./terraform.tfvars.original) as terraform.tfvars and update necessary values.

- Update terraform state backend in provider.tf

```bash
    terraform plan
    terraform apply --auto-approve
```

_note:_ `var.ec2_ami` : Any ubuntu based images which supports hvm can be used. Refer https://cloud-images.ubuntu.com/locator/ec2 to select correct ami_id from respective region.

- Use provider_override.tf to override s3 backend or any other provider specific configuration. 

## Roost License
 
 Two ways terraform loads license key.
 1. Use of license_key variable
 2. Using license file (license.ral)

 license_key has higher precedence over license file.
 Either provide license_key = "..." in terraform.tfvars or keep roost provided license file (license.ral) into data directory. (data/license.ral).

 **Renew using license file**: In order to redeply renewed licence file, keep latest license file in the path `data/license.ral` and run `terraform apply`.
 **Renew using license key**: set correct value in license_key in terraform.tfvars and run `terraform apply`

 ## Upgrade RoostGPT version.

 1. use appropriate version in terraform.tfvars (var.roost_version)
 2. Run `terraform apply` 

## Important input parameters to set -

- region
- route53_hosted_zone_id
- ec2_ami
- enterprise_dns
- ip_block_vpc (VPC CIDR where Roost would be setup)
- okta_client_id or appropriate auth provider
- company (org name)
- RDS details

## How to ssh into instance

Terraform generates new keypair and stores in [data](./data) if var.generate_key_pair = true.
If wish to use pre-existing key (say keypair1), follow below two steps.

1. set var.key_pair = keypair1 && var.generate_key_pair = false.

1. Place keypair in [data](./data) without extention name. e.g. (instead of keypair1.pem, it should be keypair1)

1. `terraform import aws_key_pair.ssh data/keypair1`
