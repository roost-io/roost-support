resource "aws_security_group" "loadbalancer" {
  name        = "Roost LoadBalancer SG"
  description = "Security group for loadbalancer"
  vpc_id      = aws_vpc.vpc.id
  revoke_rules_on_delete = true

  egress {
    from_port        = 0
    to_port          = 0
    protocol         = "-1"
    cidr_blocks      = ["0.0.0.0/0"]
    ipv6_cidr_blocks = ["::/0"]
  }
}

# Allow HTTPS traffic to loadbalancer from anywhere
resource "aws_security_group_rule" "loadbalancer-https" {
  type              = "ingress"
  from_port         = 443
  to_port           = 443
  protocol          = "tcp"
  security_group_id = aws_security_group.loadbalancer.id
  cidr_blocks       = ["0.0.0.0/0"]
  description       = "Allow HTTPS traffic to loadbalancer from anywhere"
}


# resource "aws_security_group" "loadbalancer" {
#   name        = "Roost LoadBalancer SG"
#   description = "Allow TLS inbound traffic"
#   vpc_id      = aws_vpc.vpc.id
#   ingress {
#     description      = "HTTPS connection from internet"
#     from_port        = 443
#     to_port          = 443
#     protocol         = "tcp"
#     cidr_blocks      = ["0.0.0.0/0"]
#     ipv6_cidr_blocks = ["::/0"]
#   }
#   egress {
#     from_port        = 0
#     to_port          = 0
#     protocol         = "-1"
#     cidr_blocks      = ["0.0.0.0/0"]
#     ipv6_cidr_blocks = ["::/0"]
#   }
#   tags = {
#     Project = local.prefix
#     Name    = join("-", [var.prefix, "loadbalancer-sg"])
#   }
# }
# ============================================================================

resource "aws_security_group" "bastion" {
  name        = "Roost Bastion SG"
  description = "Security group for bastion"
  vpc_id      = aws_vpc.vpc.id
  revoke_rules_on_delete = true

  egress {
    from_port        = 0
    to_port          = 0
    protocol         = "-1"
    cidr_blocks      = ["0.0.0.0/0"]
    ipv6_cidr_blocks = ["::/0"]
  }
}

# Allow HTTPS traffic to loadbalancer from anywhere
resource "aws_security_group_rule" "bastion-ssh" {
  type              = "ingress"
  from_port         = 22
  to_port           = 22
  protocol          = "tcp"
  security_group_id = aws_security_group.bastion.id
  cidr_blocks       = ["0.0.0.0/0"]
  description       = "Allow ssh to bastion from anywhere"
}


# resource "aws_security_group" "bastion" {
#   name                   = "Roost Bastion SG"
#   description            = "Allow SSH from anywhere to Bastion"
#   vpc_id                 = aws_vpc.vpc.id
#   revoke_rules_on_delete = true
#   ingress {
#     description      = "Allow SSH from Internet"
#     protocol         = "tcp"
#     from_port        = 22
#     to_port          = 22
#     cidr_blocks      = ["0.0.0.0/0"]
#     ipv6_cidr_blocks = ["::/0"]
#   }

#   egress {
#     from_port        = 0
#     to_port          = 0
#     protocol         = "-1"
#     cidr_blocks      = ["0.0.0.0/0"]
#     ipv6_cidr_blocks = ["::/0"]
#   }
#   tags = {
#     Project = local.prefix
#     Name    = join("-", [var.prefix, "bastion-sg"])
#   }
# }

# ===================================================================

resource "aws_default_security_group" "roost_vpc" {
  # name                   = "Roost VPC SG"
  # description = "Allow ALL traffic routing within VPC"
  vpc_id                 = aws_vpc.vpc.id
  revoke_rules_on_delete = true

  ingress {
    description      = "Allow all traffic from within current VPC"
    protocol         = -1
    self             = true
    from_port        = 0
    to_port          = 0
    ipv6_cidr_blocks = ["::/0"]
  }

  #  ingress {
  #    description     = "Allow SSH from SSH server only"
  #    protocol        = "tcp"
  #    from_port       = 22
  #    to_port         = 22
  #    security_groups = [aws_security_group.bastion.id]
  #  }

  egress {
    from_port        = 0
    to_port          = 0
    protocol         = "-1"
    cidr_blocks      = ["0.0.0.0/0"]
    ipv6_cidr_blocks = ["::/0"]
  }

  tags = {
    Project = local.prefix
    Name    = join("-", [var.prefix, "vpc-sg"])
  }
}


# ===================================================================


resource "aws_security_group" "controlplane" {
  name                   = "Roost Enterprise ControlPlane SG"
  description            = "Security group for Roost controlplane"
  vpc_id                 = aws_vpc.vpc.id
  revoke_rules_on_delete = true

  egress {
    from_port        = 0
    to_port          = 0
    protocol         = "-1"
    cidr_blocks      = ["0.0.0.0/0"]
    ipv6_cidr_blocks = ["::/0"]
  }
}

# Allow ssh from roost-gpt server to controlplane server
resource "aws_security_group_rule" "roostgpt-controlplane-ssh" {
  type                     = "ingress"
  from_port                = 22
  to_port                  = 22
  protocol                 = "tcp"
  security_group_id        = aws_security_group.controlplane.id
  source_security_group_id = aws_security_group.roostgpt.id
}
# Allow ssh from bastion server to controlplane server
resource "aws_security_group_rule" "bastion-controlplane-ssh" {
  type                     = "ingress"
  from_port                = 22
  to_port                  = 22
  protocol                 = "tcp"
  security_group_id        = aws_security_group.controlplane.id
  source_security_group_id = aws_security_group.bastion.id
}

# Allow HTTPS traffic from loadbalancer
resource "aws_security_group_rule" "loadbalancer-controlplane-https" {
  type                     = "ingress"
  from_port                = 443
  to_port                  = 443
  protocol                 = "tcp"
  security_group_id        = aws_security_group.controlplane.id
  source_security_group_id = aws_security_group.loadbalancer.id
}

# resource "aws_security_group" "controlplane" {
#   name                   = "Roost Enterprise ControlPlane SG"
#   description            = "Security group for Roost controlplane"
#   vpc_id                 = aws_vpc.vpc.id
#   revoke_rules_on_delete = true

#   ingress {
#     description     = "Allow HTTPS from LoadBalancer"
#     protocol        = "tcp"
#     from_port       = 443
#     to_port         = 443
#     security_groups = [aws_security_group.loadbalancer.id]
#   }

#   egress {
#     from_port        = 0
#     to_port          = 0
#     protocol         = "-1"
#     cidr_blocks      = ["0.0.0.0/0"]
#     ipv6_cidr_blocks = ["::/0"]
#   }

#   tags = {
#     Project = local.prefix
#     Name    = join("-", [var.prefix, "controlplane-sg"])
#   }
# }

# ===================================================================


resource "aws_security_group" "roostgpt" {
  name                   = "RoostGPT Server SG"
  description            = "Security group for RoostGPT server"
  vpc_id                 = aws_vpc.vpc.id
  revoke_rules_on_delete = true

  egress {
    from_port        = 0
    to_port          = 0
    protocol         = "-1"
    cidr_blocks      = ["0.0.0.0/0"]
    ipv6_cidr_blocks = ["::/0"]
  }
}

# Allow ssh from bastion to roost-gpt server
resource "aws_security_group_rule" "bastion-roostgpt-ssh" {
  type                     = "ingress"
  from_port                = 22
  to_port                  = 22
  protocol                 = "tcp"
  security_group_id        = aws_security_group.roostgpt.id
  source_security_group_id = aws_security_group.bastion.id
}

# Allow ssh from roost-gpt server to controlplane server
resource "aws_security_group_rule" "controlplane-roostgpte-ssh" {
  type                     = "ingress"
  from_port                = 22
  to_port                  = 22
  protocol                 = "tcp"
  security_group_id        = aws_security_group.roostgpt.id
  source_security_group_id = aws_security_group.controlplane.id
}

# Allow ingress Port 5000 to 50005 TCP for docker to roostgpt server 
resource "aws_security_group_rule" "docker-roostgpt-custom" {
  type              = "ingress"
  from_port         = 5000
  to_port           = 5005
  protocol          = "tcp"
  security_group_id = aws_security_group.roostgpt.id
  cidr_blocks       = ["0.0.0.0/0"]
  description       = "Custom TCP for Docker"
}

# Allow CUSTOM TCP range for gotty terminal from controlplane to roostgpt server
resource "aws_security_group_rule" "controlplane-roostgpt-gotty" {
  type                     = "ingress"
  from_port                = 60001
  to_port                  = 62120
  protocol                 = "tcp"
  security_group_id        = aws_security_group.roostgpt.id
  source_security_group_id = aws_security_group.controlplane.id
}

# Allow CUSTOM TCP range for gotty terminal from controlplane to roostgpt server
resource "aws_security_group_rule" "bastion-roostgpt-gotty" {
  type                     = "ingress"
  from_port                = 60001
  to_port                  = 62120
  protocol                 = "tcp"
  security_group_id        = aws_security_group.roostgpt.id
  source_security_group_id = aws_security_group.bastion.id
}


# resource "aws_security_group" "roostgpt" {
#   name                   = "RoostGPT Server SG"
#   description            = "Security group for RoostGPT server"
#   vpc_id                 = aws_vpc.vpc.id
#   revoke_rules_on_delete = true

#   ingress {
#     description     = "SSH from Bastion"
#     protocol        = "tcp"
#     from_port       = 22
#     to_port         = 22
#     security_groups = [aws_security_group.bastion.id]
#   }
#   ingress {
#     description     = "SSH from Controlplane"
#     protocol        = "tcp"
#     from_port       = 22
#     to_port         = 22
#     security_groups = [aws_security_group.controlplane.id]
#   }
#   ingress {
#     description      = "Custom TCP for Docker"
#     from_port        = 5000
#     to_port          = 5005
#     protocol         = "tcp"
#     cidr_blocks      = ["0.0.0.0/0"]
#     ipv6_cidr_blocks = ["::/0"]
#   }
#   ingress {
#     description     = "Custom TCP from Controlplane"
#     from_port       = 60001
#     to_port         = 62120
#     protocol        = "tcp"
#     security_groups = [aws_security_group.controlplane.id]
#   }

#   egress {
#     from_port        = 0
#     to_port          = 0
#     protocol         = "-1"
#     cidr_blocks      = ["0.0.0.0/0"]
#     ipv6_cidr_blocks = ["::/0"]
#   }

#   tags = {
#     Project = local.prefix
#     Name    = join("-", [var.prefix, "roostgpt-sg"])
#   }
# }

# ==================================================================================



# This security group is of no use
# resource "aws_security_group" "jumphost" {
#   name        = "Roost JumpHost Server SG"
#   description = "Security group for Roost jumphost"
#   vpc_id      = aws_vpc.vpc.id
#   ingress {
#     description     = "SSH from Bastion"
#     from_port       = 22
#     to_port         = 22
#     protocol        = "tcp"
#     security_groups = [aws_security_group.bastion.id]
#   }
#   ingress {
#     description     = "SSH from Controlplane"
#     protocol        = "tcp"
#     from_port       = 22
#     to_port         = 22
#     security_groups = [aws_security_group.controlplane.id]
#   }
#   ingress {
#     description      = "Custom TCP for Docker"
#     from_port        = 5000
#     to_port          = 5005
#     protocol         = "tcp"
#     cidr_blocks      = ["0.0.0.0/0"]
#     ipv6_cidr_blocks = ["::/0"]
#   }
#   ingress {
#     description     = "Custom TCP from Controlplane"
#     from_port       = 60001
#     to_port         = 62120
#     protocol        = "tcp"
#     security_groups = [aws_security_group.controlplane.id]
#   }
#   ingress {
#     description     = "Allow RoostAPI access from RoostGPT Server"
#     from_port       = 60001
#     to_port         = 60001
#     protocol        = "tcp"
#     security_groups = [aws_security_group.roostgpt.id]
#   }
#   egress {
#     from_port        = 0
#     to_port          = 0
#     protocol         = "-1"
#     cidr_blocks      = ["0.0.0.0/0"]
#     ipv6_cidr_blocks = ["::/0"]
#   }
#   tags = {
#     Project = local.prefix
#     Name    = join("-", [var.prefix, "jumphost-sg"])
#   }
# }

