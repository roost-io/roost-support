data "aws_route53_zone" "roostgpt" {
  count   = var.route53_hosted_zone_id == "" ? 0 : 1
  zone_id = var.route53_hosted_zone_id
}

resource "aws_route53_record" "roostgpt" {
  count   = var.route53_hosted_zone_id == "" ? 0 : 1
  zone_id = data.aws_route53_zone.roostgpt[0].zone_id
  name    = var.enterprise_dns
  type    = "A"
  alias {
      name                   = aws_lb.roostgpt_load_balancer.dns_name
      zone_id                = aws_lb.roostgpt_load_balancer.zone_id
      evaluate_target_health = true
  }
}