resource "aws_lb" "roostgpt_load_balancer" {
  name                       = join("-", [var.prefix, "loadbalancer"])
  load_balancer_type         = "application"
  security_groups            = [aws_security_group.loadbalancer.id]
  subnets                    = [aws_subnet.roostgpt_public_subnet1.id, aws_subnet.roostgpt_public_subnet2.id]
  enable_deletion_protection = var.deletion_protection
  tags = {
    Project = local.prefix
    Name    = join("-", [var.prefix, "loadbalancer"])
  }
}

resource "aws_lb_listener" "roostgpt-lb_listner" {
  load_balancer_arn = aws_lb.roostgpt_load_balancer.arn
  certificate_arn   = var.certificate_arn == "" ? module.acm[0].acm_certificate_arn : var.certificate_arn
  port              = "443"
  protocol          = "HTTPS"
  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.controlplane.arn
  }
  tags = {
    Project = local.prefix
    Name    = join("-", [var.prefix, "loadbalancer-listner"])
  }
}
